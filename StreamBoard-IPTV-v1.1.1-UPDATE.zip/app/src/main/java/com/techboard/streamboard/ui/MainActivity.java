package com.techboard.streamboard.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.graphics.Color;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.graphics.Typeface;

import com.techboard.streamboard.core.ChannelStore;
import com.techboard.streamboard.core.M3uParser;
import com.techboard.streamboard.core.PlaylistDownloader;
import com.techboard.streamboard.core.StreamHealthChecker;
import com.techboard.streamboard.model.Channel;
import com.techboard.streamboard.model.ChannelGroup;
import com.techboard.streamboard.model.PlaylistSource;

import java.net.URI;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Separate IPTV app. Newly imported channels never become playable until explicitly allowed. */
public class MainActivity extends Activity {
    private ChannelStore store;
    private final LogoLoader logos=new LogoLoader();
    private final ExecutorService pool=Executors.newFixedThreadPool(4);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private LinearLayout main, panel, navBar, playerHolder, headerBar;
    private InlinePlayer inlinePlayer;
    private boolean playerFullscreen=false;
    private int sidePadding=14;
    private boolean destroyed=false;
    private TextView summary, activityMessage;
    private ListView listView;
    private ChannelAdapter channelAdapter;
    private Spinner categorySpinner;
    private final List<ChannelGroup> filtered=new ArrayList<>();
    private String tab="watch", category="All categories", search="";
    private final Map<String,String> playlistState=new ConcurrentHashMap<>();
    private final AtomicInteger running=new AtomicInteger();
    private boolean startedImport=false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);getWindow().setNavigationBarColor(Ui.BG);
        // Loading a large saved catalog synchronously was blocking Android's UI thread.
        LinearLayout loading=column();loading.setBackgroundColor(Ui.BG);
        Ui.padding(loading,this,20,30);
        loading.addView(Ui.text(this,"STREAMBOARD",23,Ui.TEXT,true));
        loading.addView(Ui.text(this,"Loading your channel library…",14,Ui.MUTED,false));
        setContentView(loading);
        pool.execute(()->{
            try {
                ChannelStore loaded=new ChannelStore(getApplicationContext());
                ui.post(()->{
                    if(destroyed||isFinishing())return;
                    store=loaded;render();
                    if(store.rawChannels().isEmpty()&&!store.sources().isEmpty())refreshAll();
                });
            } catch(Exception error) {
                ui.post(()->{if(!destroyed)Toast.makeText(this,"Library error: "+brief(error),Toast.LENGTH_LONG).show();});
            }
        });
    }
    @Override protected void onDestroy(){
        destroyed=true;ui.removeCallbacksAndMessages(null);
        if(inlinePlayer!=null)inlinePlayer.release();
        pool.shutdownNow();logos.close();super.onDestroy();
    }
    @Override protected void onStop(){super.onStop();if(inlinePlayer!=null)inlinePlayer.pauseForBackground();}
    @Override protected void onStart(){super.onStart();if(inlinePlayer!=null)inlinePlayer.resumeForeground();}
    @Override public void onConfigurationChanged(android.content.res.Configuration c){super.onConfigurationChanged(c);
        if(inlinePlayer!=null)inlinePlayer.onConfigurationChanged(playerFullscreen);
    }
    @Override public void onBackPressed(){
        if(playerFullscreen){setPlayerFullscreen(false);return;}
        super.onBackPressed();
    }
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams lp(int width,int height){return new LinearLayout.LayoutParams(width<0?width:Ui.dp(this,width),height<0?height:Ui.dp(this,height));}
    private void gap(LinearLayout p,int h){View v=new View(this);p.addView(v,lp(1,h));}
    /** One permanent view tree: do not tear down the video surface on tab/category changes. */
    private void render() {
        if(store==null)return;
        if(main==null){
            main=column();main.setBackgroundColor(Ui.BG);
            sidePadding=getResources().getConfiguration().screenWidthDp>=600?26:14;
            main.setPadding(Ui.dp(this,sidePadding),Ui.dp(this,10),Ui.dp(this,sidePadding),Ui.dp(this,6));
            setContentView(main);
            headerBar=row();
            TextView icon=Ui.text(this,"▶",19,Ui.BG,true);icon.setGravity(Gravity.CENTER);
            icon.setBackground(Ui.bg(Ui.PRIMARY,12,this));headerBar.addView(icon,lp(42,42));
            LinearLayout identity=column();identity.addView(Ui.text(this,"STREAMBOARD",18,Ui.TEXT,true));
            summary=Ui.text(this,"",11,Ui.MUTED,false);identity.addView(summary);
            LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,-2,1);
            hp.setMargins(Ui.dp(this,10),0,0,0);headerBar.addView(identity,hp);
            headerBar.addView(Ui.text(this,"v1.1.1",11,Ui.PRIMARY,true));
            main.addView(headerBar);gap(main,8);
            playerHolder=column();playerHolder.setVisibility(View.GONE);
            main.addView(playerHolder,new LinearLayout.LayoutParams(-1,-2));
            panel=column();main.addView(panel,new LinearLayout.LayoutParams(-1,0,1));
            navBar=row();navBar.setBackground(Ui.bg(Ui.PANEL,14,this));
            Ui.padding(navBar,this,5,5);
            main.addView(navBar);inlinePlayer=new InlinePlayer(this,store,playerHolder,this::setPlayerFullscreen,this::navigateChannel);
        }
        panel.removeAllViews();
        if(tab.equals("watch")||tab.equals("favorites"))renderWatch();
        else if(tab.equals("manage"))renderManage();
        else renderPlaylists();
        navBar.removeAllViews();
        String[] labels={"◉ Live","★ Saved","☑ Access","≡ Sources"};
        String[] names={"watch","favorites","manage","playlists"};
        for(int i=0;i<labels.length;i++){
            final String selection=names[i];Button btn=Ui.button(this,labels[i],tab.equals(selection));
            btn.setTextSize(11);
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,Ui.dp(this,43),1);
            params.setMargins(Ui.dp(this,2),0,Ui.dp(this,2),0);
            navBar.addView(btn,params);
            btn.setOnClickListener(v->{tab=selection;category="All categories";search="";render();});
        }
        updateSummary();
        if(inlinePlayer!=null)inlinePlayer.revalidate();
    }
    private void setPlayerFullscreen(boolean enabled){
        playerFullscreen=enabled;
        if(main==null)return;
        headerBar.setVisibility(enabled?View.GONE:View.VISIBLE);
        panel.setVisibility(enabled?View.GONE:View.VISIBLE);
        navBar.setVisibility(enabled?View.GONE:View.VISIBLE);
        playerHolder.setLayoutParams(enabled
            ?new LinearLayout.LayoutParams(-1,0,1)
            :new LinearLayout.LayoutParams(-1,-2));
        main.setPadding(enabled?0:Ui.dp(this,sidePadding),enabled?0:Ui.dp(this,10),
            enabled?0:Ui.dp(this,sidePadding),enabled?0:Ui.dp(this,6));
        if(inlinePlayer!=null)inlinePlayer.onConfigurationChanged(enabled);
    }
    private void updateSummary() {
        if(summary==null)return;
        List<ChannelGroup> groups=store.mergedChannels();
        long approved=groups.stream().filter(g->g.allowed).count();
        int alternatives=0;for(ChannelGroup g:groups)alternatives+=g.feeds.size();
        summary.setText(groups.size()+" channels  ·  "+approved+" approved  ·  "+alternatives+" sources");
    }
    private void heading(LinearLayout parent,String title,String detail) {
        parent.addView(Ui.text(this,title,22,Ui.TEXT,true));gap(parent,3);
        TextView desc=Ui.text(this,detail,12,Ui.MUTED,false);parent.addView(desc);gap(parent,12);
    }
    private void renderWatch() {
        boolean favorites=tab.equals("favorites");
        LinearLayout hero=column();hero.setBackground(Ui.bg(Ui.PANEL,17,this));Ui.padding(hero,this,15,14);
        TextView kicker=Ui.text(this,favorites?"YOUR COLLECTION":"LIVE TELEVISION",11,Ui.PRIMARY,true);hero.addView(kicker);
        gap(hero,6);
        hero.addView(Ui.text(this,favorites?"Favorite channels":"Watch what you love",22,Ui.TEXT,true));
        TextView hint=Ui.text(this,favorites?"Quick access to saved and approved channels":"Only your approved channels are shown. Automatic backup sources keep playback going.",12,Ui.MUTED,false);
        hero.addView(hint);gap(hero,10);
        LinearLayout heroActions=row();
        if(!favorites){
            Button last=Ui.button(this,"▶  Resume",true);
            heroActions.addView(last,lp(118,38));
            last.setOnClickListener(v->{String id=getPreferences(MODE_PRIVATE).getString("last_channel","");
                ChannelGroup group=store.findGroup(id);if(group!=null)openPlayer(group);else toast("Select a channel to start watching");});
        }
        Button check=Ui.button(this,"↻  Check streams",false);
        LinearLayout.LayoutParams cp=lp(-2,38);cp.setMargins(Ui.dp(this,8),0,0,0);
        heroActions.addView(check,cp);check.setOnClickListener(v->testAllowed());
        hero.addView(heroActions);
        panel.addView(hero);gap(panel,12);
        renderFilters();
        setupList(false);
    }
    private void renderManage() {
        heading(panel,"Manage access","Choose visible categories and allow individual channels. New imports stay blocked.");
        TextView catLabel=Ui.text(this,"VISIBLE CATEGORIES  (tap to change)",11,Ui.MUTED,true);panel.addView(catLabel);gap(panel,7);
        HorizontalScrollView horizontal=new HorizontalScrollView(this);horizontal.setHorizontalScrollBarEnabled(false);
        LinearLayout categories=row();
        List<String> categoryNames=new ArrayList<>(allCategories());
        for(String name:categoryNames){
            boolean visible=store.categoryVisible(name);Button btn=Ui.button(this,(visible?"✓ ":"○ ")+name,visible);
            LinearLayout.LayoutParams p=lp(-2,38);p.setMargins(0,0,Ui.dp(this,7),0);
            categories.addView(btn,p);
            btn.setOnClickListener(v->{store.setCategoryVisible(name,!store.categoryVisible(name));render();});
        }
        horizontal.addView(categories);panel.addView(horizontal);gap(panel,10);
        renderFilters();
        LinearLayout bulk=row();Button allow=Ui.button(this,"Allow selected",false);Button block=Ui.button(this,"Block selected",false);
        LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(0,Ui.dp(this,43),1);p1.setMargins(0,0,Ui.dp(this,6),0);
        bulk.addView(allow,p1);bulk.addView(block,new LinearLayout.LayoutParams(0,Ui.dp(this,43),1));panel.addView(bulk);gap(panel,8);
        allow.setOnClickListener(v->bulkChange(true));block.setOnClickListener(v->bulkChange(false));
        setupList(true);
    }
    private List<String> allCategories() {
        TreeSet<String> cats=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for(ChannelGroup g:store.mergedChannels())cats.add(g.category);
        return new ArrayList<>(cats);
    }
    private void renderFilters() {
        EditText field=new EditText(this);field.setSingleLine(true);field.setTextSize(14);
        field.setHint("⌕  Find channel, category or language");
        field.setTextColor(Ui.TEXT);field.setHintTextColor(Ui.MUTED);
        field.setBackground(Ui.bg(Ui.PANEL,12,this));Ui.padding(field,this,13,11);
        field.setText(search);
        panel.addView(field,new LinearLayout.LayoutParams(-1,Ui.dp(this,49)));gap(panel,9);
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=row();
        List<String> categories=new ArrayList<>();categories.add("All categories");
        for(String candidate:allCategories())if(tab.equals("manage") || store.categoryVisible(candidate))categories.add(candidate);
        if(!categories.contains(category))category="All categories";
        for(String option:categories){
            Button chip=Ui.button(this,option.equals("All categories")?"All":option,option.equals(category));
            chip.setTextSize(12);
            LinearLayout.LayoutParams p=lp(-2,37);p.setMargins(0,0,Ui.dp(this,7),0);chips.addView(chip,p);
            chip.setOnClickListener(v->{category=option;render();});
        }
        scroller.addView(chips);panel.addView(scroller);gap(panel,9);
        final Runnable[] pending={null};
        field.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence value,int start,int before,int count){
                search=value.toString();
                if(pending[0]!=null)ui.removeCallbacks(pending[0]);
                pending[0]=()->{if(!destroyed)updateList();};ui.postDelayed(pending[0],140);
            }
            @Override public void afterTextChanged(Editable e){}
        });
    }
    private void setupList(boolean manage) {
        channelAdapter=new ChannelAdapter(manage);
        listView=new ListView(this);listView.setDivider(null);listView.setCacheColorHint(Color.TRANSPARENT);
        listView.setBackgroundColor(Color.TRANSPARENT);listView.setFastScrollEnabled(true);listView.setAdapter(channelAdapter);
        listView.setOnItemClickListener((p,v,pos,id)->{
            if(pos>=filtered.size())return;
            ChannelGroup g=filtered.get(pos);
            if(manage)openChannelOptions(g);else openPlayer(g);
        });
        panel.addView(listView,new LinearLayout.LayoutParams(-1,0,1));
        TextView empty=Ui.text(this,manage?"No channels imported yet. Add a playlist and refresh it.":"No approved channels yet. Open Channels to select what you want to watch.",14,Ui.MUTED,false);
        empty.setGravity(Gravity.CENTER);Ui.padding(empty,this,14,15);
        panel.addView(empty,new LinearLayout.LayoutParams(-1,0,1));listView.setEmptyView(empty);
        updateList();
    }
    private void updateList() {
        if(channelAdapter==null||listView==null||!(tab.equals("watch")||tab.equals("favorites")||tab.equals("manage")))return;
        filtered.clear();
        for(ChannelGroup group:store.mergedChannels()) {
            if((tab.equals("watch") || tab.equals("favorites"))&&(!group.allowed||!store.categoryVisible(group.category)))continue;
            if(tab.equals("favorites")&&!store.isFavorite(group))continue;
            if(!"All categories".equals(category)&&!category.equals(group.category))continue;
            if(!search.trim().isEmpty()){
                String q=search.toLowerCase(Locale.ROOT);
                if(!group.name.toLowerCase(Locale.ROOT).contains(q) && !group.category.toLowerCase(Locale.ROOT).contains(q)
                    && !group.language.toLowerCase(Locale.ROOT).contains(q))continue;
            }
            filtered.add(group);
        }
        channelAdapter.notifyDataSetChanged();
    }
    private void bulkChange(boolean value) {
        List<ChannelGroup> selected=new ArrayList<>(filtered);
        if(selected.isEmpty()){toast("No channels match the filters");return;}
        String action=value?"Allow":"Block";
        new AlertDialog.Builder(this).setTitle(action+" "+selected.size()+" channels?")
            .setMessage("This only changes the channels currently shown by your search/category filters.")
            .setNegativeButton("Cancel",null)
            .setPositiveButton(action,(d,w)->{
                for(ChannelGroup group:selected)store.setAllowed(group.id,value);
                updateSummary();updateList();if(inlinePlayer!=null)inlinePlayer.revalidate();
                toast("Updated "+selected.size()+" channels");
            }).show();
    }
    private void openChannelOptions(ChannelGroup group) {
        List<String> options=new ArrayList<>();
        options.add(group.allowed?"Block channel":"Allow channel");
        options.add("Play channel");options.add("Choose preferred source ("+group.feeds.size()+")");
        options.add("Check all sources");options.add("Change category");
        options.add(store.isFavorite(group)?"Remove favorite":"Add favorite");
        new AlertDialog.Builder(this).setTitle(group.name).setItems(options.toArray(new String[0]),(d,which)->{
            switch(which) {
                case 0:store.setAllowed(group.id,!group.allowed);updateSummary();updateList();
                    if(inlinePlayer!=null)inlinePlayer.revalidate();break;
                case 1:openPlayer(group);break;
                case 2:choosePreferred(group);break;
                case 3:checkGroup(group);break;
                case 4:changeCategory(group);break;
                case 5:store.toggleFavorite(group);toast("Favorite updated");break;
            }
        }).setNegativeButton("Close",null).show();
    }
    private void choosePreferred(ChannelGroup group) {
        String[] names=new String[group.feeds.size()+1];names[0]="Automatic (first available)";
        for(int i=0;i<group.feeds.size();i++){
            Channel c=group.feeds.get(i);
            names[i+1]=c.sourceName+" — "+host(c.streamUrl)+" — "+c.status;
        }
        new AlertDialog.Builder(this).setTitle("Preferred source: "+group.name)
            .setSingleChoiceItems(names,-1,(dialog,which)->{
                store.setPreferredSource(group.id,which==0?"":group.feeds.get(which-1).streamUrl);
                toast("Source preference saved");dialog.dismiss();
            }).setNegativeButton("Cancel",null).show();
    }
    private void changeCategory(ChannelGroup group) {
        List<String> categories=new ArrayList<>(allCategories());
        for(String extra:new String[]{"Kids","News","Sports","Movies","Music","Entertainment","Documentary","Religious","International","Other"}){
            if(!categories.contains(extra))categories.add(extra);
        }
        Collections.sort(categories,String.CASE_INSENSITIVE_ORDER);
        new AlertDialog.Builder(this).setTitle("Category for "+group.name)
            .setItems(categories.toArray(new String[0]),(d,which)->{
                store.overrideCategory(group,categories.get(which));render();
            }).show();
    }
    private void openPlayer(ChannelGroup g) {
        ChannelGroup latest=store.findGroup(g.id);
        if(latest==null||!latest.allowed||!store.categoryVisible(latest.category)){
            new AlertDialog.Builder(this).setTitle("Channel not allowed")
                .setMessage("Enable this channel and its category in Channels before playing.")
                .setPositiveButton("OK",null).show();return;
        }
        getPreferences(MODE_PRIVATE).edit().putString("last_channel",latest.id).apply();
        if(inlinePlayer!=null)inlinePlayer.play(latest);
    }
    private void navigateChannel(int delta){
        if(inlinePlayer==null||store==null)return;
        List<ChannelGroup> options=new ArrayList<>();
        // Respect the current search/category filter while browsing on the Live tab.
        if((tab.equals("watch")||tab.equals("favorites"))&&!filtered.isEmpty()){
            for(ChannelGroup g:filtered)if(g.allowed&&store.categoryVisible(g.category))options.add(g);
        }else for(ChannelGroup g:store.mergedChannels()){
            if(g.allowed&&store.categoryVisible(g.category))options.add(g);
        }
        if(options.isEmpty())return;
        int current=-1;for(int i=0;i<options.size();i++){
            if(options.get(i).id.equals(inlinePlayer.currentId())){current=i;break;}
        }
        int next=current<0?(delta>0?0:options.size()-1):Math.floorMod(current+delta,options.size());
        openPlayer(options.get(next));
    }
    private void renderPlaylists() {
        heading(panel,"Playlist sources","Import M3U URLs. Refresh sources independently; existing channels are kept if a refresh fails.");
        LinearLayout buttons=row();Button add=Ui.button(this,"+ Add playlist",true);
        Button refresh=Ui.button(this,"↻ Refresh all",false);
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,Ui.dp(this,43),1);a.setMargins(0,0,Ui.dp(this,7),0);
        buttons.addView(add,a);buttons.addView(refresh,new LinearLayout.LayoutParams(0,Ui.dp(this,43),1));
        panel.addView(buttons);gap(panel,8);
        add.setOnClickListener(v->addPlaylistDialog());refresh.setOnClickListener(v->refreshAll());
        activityMessage=Ui.text(this,"Playlist links are user-supplied. Only use sources you are authorized to access.",12,Ui.MUTED,false);
        panel.addView(activityMessage);gap(panel,8);
        ScrollView scroll=new ScrollView(this);LinearLayout items=column();
        for(PlaylistSource source:store.sources()){
            LinearLayout card=column();card.setBackground(Ui.bg(Ui.PANEL_ALT,12,this));Ui.padding(card,this,12,10);
            card.addView(Ui.text(this,source.title,16,Ui.TEXT,true));
            long count=store.rawChannels().stream().filter(c->c.sourceId.equals(source.id)).count();
            card.addView(Ui.text(this,host(source.url)+"   ·   "+count+" entries",12,Ui.MUTED,false));
            String status=playlistState.getOrDefault(source.id,"");
            if(!status.isEmpty())card.addView(Ui.text(this,status,12,Ui.PRIMARY,false));
            gap(card,7);
            LinearLayout actions=row();Button update=Ui.button(this,"Refresh",false);Button inspect=Ui.button(this,"Inspect",false);
            Button remove=Ui.button(this,"Remove",false);
            actions.addView(update,new LinearLayout.LayoutParams(0,Ui.dp(this,39),1));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,Ui.dp(this,39),1);ip.setMargins(Ui.dp(this,5),0,0,0);
            actions.addView(inspect,ip);
            LinearLayout.LayoutParams rm=new LinearLayout.LayoutParams(0,Ui.dp(this,39),1);
            rm.setMargins(Ui.dp(this,5),0,0,0);actions.addView(remove,rm);
            inspect.setOnClickListener(v->inspectSource(source));
            update.setOnClickListener(v->refreshSource(source));
            remove.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Remove "+source.title+"?")
                .setMessage("Only channels from this playlist will be removed. Approvals for other channels remain.")
                .setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->{store.removeSource(source.id);render();}).show());
            card.addView(actions);LinearLayout.LayoutParams margins=lp(-1,-2);margins.setMargins(0,0,0,Ui.dp(this,9));items.addView(card,margins);
        }
        scroll.addView(items);panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    /** Explain what a fetched M3U actually contains; avoid fabricated channel counts. */
    private void inspectSource(PlaylistSource source) {
        List<Channel> feeds=new ArrayList<>();
        for(Channel c:store.rawChannels())if(source.id.equals(c.sourceId))feeds.add(c);
        Map<String,Integer> categories=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        Map<String,Integer> hosts=new HashMap<>();
        int logos=0, guide=0, hls=0;Set<String> unique=new HashSet<>();
        for(Channel c:feeds){
            categories.merge(c.category.isEmpty()?"Other":c.category,1,Integer::sum);
            hosts.merge(host(c.streamUrl),1,Integer::sum);
            if(!c.logoUrl.isEmpty())logos++;
            if(!c.tvgId.isEmpty())guide++;
            if(c.streamUrl.toLowerCase(Locale.ROOT).contains(".m3u8"))hls++;
            unique.add(c.streamUrl);
        }
        List<Map.Entry<String,Integer>> domains=new ArrayList<>(hosts.entrySet());
        domains.sort((a,b)->Integer.compare(b.getValue(),a.getValue()));
        StringBuilder report=new StringBuilder();
        report.append("Playlist: ").append(source.title).append("\nURL: ").append(source.url)
            .append("\n\nIndexed entries: ").append(feeds.size())
            .append("\nUnique URLs: ").append(unique.size())
            .append("\nEntries with logos: ").append(logos)
            .append("\nEntries with TV guide IDs: ").append(guide)
            .append("\nURLs containing .m3u8: ").append(hls)
            .append("\n\nCategories (from last successful import):\n");
        for(Map.Entry<String,Integer> e:categories.entrySet())report.append("  ").append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        report.append("\nTop stream domains:\n");
        for(int i=0;i<Math.min(10,domains.size());i++)report.append("  ")
            .append(domains.get(i).getKey()).append(": ").append(domains.get(i).getValue()).append('\n');
        report.append("\nThese are imported metadata counts, NOT checks that video is currently playing. ")
            .append("An HLS URL may require a token, authentication, or a particular region.");
        new AlertDialog.Builder(this).setTitle("Playlist inspection").setMessage(report.toString())
            .setPositiveButton("Close",null).show();
    }
    private void addPlaylistDialog() {
        LinearLayout container=column();Ui.padding(container,this,18,10);
        EditText title=new EditText(this);title.setHint("Playlist name");title.setSingleLine(true);
        EditText url=new EditText(this);url.setHint("https://example.com/channels.m3u");url.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);url.setSingleLine(false);url.setMinLines(2);
        container.addView(title);container.addView(url);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Add M3U / M3U8 URL").setView(container)
            .setNegativeButton("Cancel",null).setPositiveButton("Add",null).create();
        dlg.setOnShowListener(v->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn->{
            String name=title.getText().toString().trim(), address=url.getText().toString().trim();
            if(!M3uParser.isUrl(address)){url.setError("Enter a valid HTTP or HTTPS URL");return;}
            if(name.isEmpty())name=host(address);
            if(!store.addSource(name,address)){toast("Already added or invalid URL");return;}
            PlaylistSource added=null;for(PlaylistSource s:store.sources())if(s.url.equals(address))added=s;
            dlg.dismiss();render();if(added!=null)refreshSource(added);
        }));dlg.show();
    }
    private void refreshAll() {
        List<PlaylistSource> sources=store.sources();
        if(sources.isEmpty()){toast("Add a playlist first");return;}
        if(startedImport&&running.get()>0){toast("Playlist refresh already running");return;}
        startedImport=true;for(PlaylistSource s:sources)refreshSource(s);
    }
    private void refreshSource(PlaylistSource source) {
        if("Downloading...".equals(playlistState.get(source.id)))return;
        playlistState.put(source.id,"Downloading...");running.incrementAndGet();updatePlaylistStatus();
        pool.submit(()->{
            try {
                String content=PlaylistDownloader.download(source.url);
                List<Channel> parsed=M3uParser.parse(content,source.id,source.title,source.url);
                if(parsed.isEmpty())throw new IllegalStateException("No valid channels found. Previous entries retained.");
                store.replaceSourceChannels(source.id,parsed);
                playlistState.put(source.id,"Imported "+parsed.size()+" entries · awaiting approval");
            }catch(Exception error){playlistState.put(source.id,"Refresh failed: "+brief(error));}
            finally {
                running.decrementAndGet();ui.post(()->{
                    updateSummary();if(tab.equals("playlists"))render();else if(channelAdapter!=null)updateList();
                });
            }
        });
    }
    private void updatePlaylistStatus(){if(activityMessage!=null && tab.equals("playlists"))activityMessage.setText("Refreshing "+running.get()+" playlist(s)...");}
    private void checkGroup(ChannelGroup g) {
        toast("Checking "+g.feeds.size()+" source(s) in background");
        for(Channel feed:g.feeds)pool.submit(()->{
            StreamHealthChecker.check(feed);ui.post(()->{if(tab.equals("manage"))updateList();});
        });
    }
    private void testAllowed() {
        List<ChannelGroup> permitted=new ArrayList<>();for(ChannelGroup g:store.mergedChannels())if(g.allowed && store.categoryVisible(g.category))permitted.add(g);
        if(permitted.isEmpty()){toast("Approve channels first");return;}
        if(permitted.size()>40) {toast("Checking 40 channels per batch to keep the app responsive");permitted=permitted.subList(0,40);}
        int total=permitted.size();AtomicInteger done=new AtomicInteger();
        for(ChannelGroup g:permitted){
            pool.submit(()->{
                for(Channel feed:g.feeds){StreamHealthChecker.check(feed);if("REACHABLE".equals(feed.status))break;}
                int finished=done.incrementAndGet();
                if(finished==total || finished%10==0) ui.post(()->{updateList();toast("Checked "+finished+" of "+total);});
            });
        }
        toast("Started checking "+total+" approved channels");
    }
    private String brief(Exception ex) {String e=ex.getMessage();return e==null?ex.getClass().getSimpleName():e.length()>115?e.substring(0,115):e;}
    private static String host(String url) {try {return new URI(url).getHost();}catch(Exception e){return "Source";}}
    private void toast(String s) {Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    /** View-holder rows recycle artwork and text; avoid allocating a view tree while scrolling. */
    private final class ChannelAdapter extends BaseAdapter {
        private final boolean manage;
        ChannelAdapter(boolean manage){this.manage=manage;}
        @Override public int getCount(){return filtered.size();}
        @Override public Object getItem(int pos){return filtered.get(pos);}
        @Override public long getItemId(int pos){return pos;}
        @Override public boolean hasStableIds(){return false;}
        @Override public View getView(int pos,View convertView,ViewGroup parent){
            ChannelGroup g=filtered.get(pos);
            Holder h;
            if(convertView==null){
                h=new Holder();
                LinearLayout outer=column();
                LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);
                Ui.padding(card,MainActivity.this,11,10);
                card.setBackground(Ui.bg(Ui.PANEL,14,MainActivity.this));
                FrameLayout art=new FrameLayout(MainActivity.this);
                h.glyph=Ui.text(MainActivity.this,"TV",13,Ui.PRIMARY,true);
                h.glyph.setGravity(Gravity.CENTER);h.glyph.setBackground(Ui.bg(Ui.PANEL_ALT,11,MainActivity.this));
                art.addView(h.glyph,new FrameLayout.LayoutParams(-1,-1));
                h.logo=new ImageView(MainActivity.this);h.logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
                h.logo.setBackground(Ui.bg(Ui.PANEL_ALT,11,MainActivity.this));
                art.addView(h.logo,new FrameLayout.LayoutParams(-1,-1));
                card.addView(art,lp(51,51));
                LinearLayout meta=column();
                h.name=Ui.text(MainActivity.this,"",15,Ui.TEXT,true);h.name.setMaxLines(1);meta.addView(h.name);
                h.subtitle=Ui.text(MainActivity.this,"",12,Ui.MUTED,false);h.subtitle.setMaxLines(2);meta.addView(h.subtitle);
                LinearLayout.LayoutParams metaP=new LinearLayout.LayoutParams(0,-2,1);metaP.setMargins(Ui.dp(MainActivity.this,10),0,Ui.dp(MainActivity.this,7),0);
                card.addView(meta,metaP);
                if(manage){
                    h.toggle=new Switch(MainActivity.this);h.toggle.setContentDescription("Allow channel");card.addView(h.toggle);
                }else{
                    h.star=Ui.text(MainActivity.this,"☆",24,Ui.MUTED,false);
                    h.star.setGravity(Gravity.CENTER);card.addView(h.star,lp(42,48));
                }
                LinearLayout.LayoutParams rowP=lp(-1,-2);rowP.setMargins(0,0,0,Ui.dp(MainActivity.this,7));
                outer.addView(card,rowP);outer.setTag(h);convertView=outer;
            }else h=(Holder)convertView.getTag();
            h.name.setText(g.name);
            h.glyph.setText(g.name.trim().isEmpty()?"TV":g.name.trim().substring(0,Math.min(2,g.name.trim().length())).toUpperCase(Locale.ROOT));
            StringBuilder detail=new StringBuilder(g.category).append("  ·  ").append(g.feeds.size()).append(g.feeds.size()==1?" source":" sources");
            if(!g.language.isEmpty())detail.append("  ·  ").append(g.language);
            if(!manage)detail.append("  ·  ").append(g.feeds.stream().anyMatch(c->"REACHABLE".equals(c.status))?"Reachable":"Ready to test");
            h.subtitle.setText(detail.toString());
            logos.bind(g.logoUrl,h.logo,h.glyph);
            final Holder bound=h;
            if(manage){
                h.toggle.setOnCheckedChangeListener(null);h.toggle.setChecked(g.allowed);
                h.toggle.setOnCheckedChangeListener((button,on)->{
                    store.setAllowed(g.id,on);g.allowed=on;updateSummary();
                    if(inlinePlayer!=null)inlinePlayer.revalidate();
                });
            }else{
                h.star.setText(store.isFavorite(g)?"★":"☆");
                h.star.setTextColor(store.isFavorite(g)?Ui.PRIMARY:Ui.MUTED);
                h.star.setOnClickListener(v->{store.toggleFavorite(g);bound.star.setText(store.isFavorite(g)?"★":"☆");
                    bound.star.setTextColor(store.isFavorite(g)?Ui.PRIMARY:Ui.MUTED);
                    if(tab.equals("favorites"))updateList();});
            }
            return convertView;
        }
    }
    private static final class Holder {
        TextView name,subtitle,glyph,star;
        ImageView logo;
        Switch toggle;
    }
}
